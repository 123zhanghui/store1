'''
编写一个函数，传入一个列表，并统计每个数字出现的次数。返回字典数据：{21:3,56:9,10:3}
'''
dict = {}
list = []
def times():
    for i in range(1, 4):
        a = 21 * 1
        list.append(a)
    for j in range(1, 10):
        b = 56 * 1
        list.append(b)
    for k in range(1, 4):
        c = 10 * 1
        list.append(c)
    print(list)
    print("21:", list.count(21), "56:", list.count(56), "10:", list.count(10), )
times()
