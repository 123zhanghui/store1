'''
dict = {"k1":"v1","k2":"v2","k3":"v3"}
#1、请循环遍历出所有的key
#2、请循环遍历出所有的value
# 3、请在字典中增加一个键值对,"k4":"v4"
'''
dict={"k1":"v1","k2":"v2","k3":"v3"}
for i in dict:
    print(i)
for i,y in dict.items():
    print(y)
dict["k4"]="v4"
print(dict)
dict.update({"k5":"v5"})
print(dict)
dict.pop("k5")
print(dict)
dict.popitem()
print(dict)