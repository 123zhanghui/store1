'''
从键盘输入任意三边，判断是否能形成三角形，
若可以，则判断形成什么三角形
（结果判断：等腰，等边，直角，普通，不能形成三角形。）
'''
while 1:
    a=float(input("边长a="))
    b=float(input("边长b="))
    c=float(input("边长c="))
    if  (a+b)>c and (c+b)>a and (a+c)>b:
        if a**2+b**2==c**2 or  c**2+b**2==a**2 or  a**2+c**2==b**2:
           print(a,b,c,"构成直角三角形")
        elif a==b and b==c:
             print(a,b,c,"构成等边三角形")
        elif a == b or b == c or c == a:
             print(a,b,c,"构成等腰三角形")
        else:
            print(a,b,c,"构成普通三角形")
    else :
         print(a,b,c,"不能构成三角形")