'''
一只青蛙掉在井里了，井高20米，青蛙白天网上爬3米，晚上下滑2米，问第几天能出来？请编程求出。
'''
a=20
i=0
while True:
    a=a-3
    if a<0:
        print(i)
        break
    else :a=a+2
    i=i+1