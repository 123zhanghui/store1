'''
编程实现下列图形的打印

'''
for i in range(8):
    for j in range(0, 8 - i):
        print(end=" ")#print默认是打印一行,结尾加换行,end传递一个空字符串,表示这个语句没结束。
    for k in range(8 - i, 8):
        print("*", end=" ")

    print("")

# for i in range(8):
#     for j in range(0, 8 - i):
#         print("1",end=" ")#print默认是打印一行,结尾加换行,end传递一个空字符串,表示这个语句没结束。
#     for k in range(8 - i, 8):
#         print("*", end=" ")
#
#     print("")
