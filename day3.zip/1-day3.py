'''
实现输入10个数字，并打印10个数的求和结果
'''
i=1
a=0
while i<=10:
    num=int(input("请输入第"+str(i)+"个数字"))
    print(num)
    i=i+1
    a=num+a
print("10个数的和1为",a)