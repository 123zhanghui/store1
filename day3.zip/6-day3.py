'''
实现登陆系统的三次密码输入错误锁定功能（用户名：root,密码：admin）
'''
i = 0
username = input("用户名")
password = input("密码")
while i < 4:
    if username != root or password != admin:
        i = i + 1
        print("错误")
    else:
        username == a
        password == b
        print("成功")
print("锁定")

