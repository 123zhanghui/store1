'''
编程实现99乘法表的倒叙打印
'''
for j in range(9,0,-1):
    for i in range(j,0,-1):
        print(j,"x",i,"=",i*j,end="   ")
    print("")

# i=1
# while i<=9: #控制行，1-9
#     j=1
#     while j<=i:#控制每行显示的数量，1-9
#         print("%dx%d=%d"%(j,i,i*j),end=" ")
#         j=j+1#每行现实的数量加1
#     print("")#每一行结束换行
#     i+=1#行数加1
# for i in range(1,10):
#     for j in range(1,10):
#         print(j,"x",i,"=",i*j,end="   ")
#         if i==j:
#             print("")
#             break
