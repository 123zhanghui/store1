'''
使用random模块，如何产生 50~150之间的数？
'''
import  random
num =random.randint(50,150)
print(num)