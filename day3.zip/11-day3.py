'''
判断下列变量命名是否合法
标识符	是否合法	标识符	是否合法
char		    Cy%ty
Oax_li	     	$123
fLul		    3_3
BYTE		   T_T
'''
list = ["char", "Cy%ty", "Oax_li", "$123", "fLul", "3_3", "BYTE", "T_T"]

for a in list:
    b = input("标识符")
    if a == b:
        print(b, "合法")
    else:
        print(b,"非法")
