'''
用循环来实现20以内的数的阶乘。（1! +2!+3!+…..+20!）
'''
list = []
a = int(input())
n = 1
for i in range(1, a + 1):
    if a < 21:
        n = n * i
        list.append(n)
    else:
        print("超范围")
        break
print(sum(list))
