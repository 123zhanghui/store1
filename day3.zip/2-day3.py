'''
从键盘依次输入10个数，最后打印最大的数、10个数的和、和平均数
'''
a=0
p=[]
for i in range(1,4,1):
    num=int(input("请输入第"+str(i)+"个数"))
    print(num)
    a=num+a
    p.append(num)
    c=int(i)
b=a/c
print("最大的数为",max(p))
print("十个数的和为",a)
print("平均数",b)